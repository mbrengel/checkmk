from gettext import gettext


def foo():
    print(gettext('ssshhh....'))
